package com.github.minecraftschurlimods.bibliocraft.content.bigbook;

import com.github.minecraftschurlimods.bibliocraft.util.lectern.LecternUtil;
import com.mojang.datafixers.util.Either;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.function.Supplier;

public record SetBigBookPageInLecternPacket(int page, Either<InteractionHand, BlockPos> target) {

    public void encode(FriendlyByteBuf buf) {
        buf.writeInt(page);
        buf.writeBoolean(target.left().isPresent());
        if (target.left().isPresent()) {
            buf.writeBoolean(target.left().get() == InteractionHand.MAIN_HAND);
        } else {
            buf.writeBlockPos(target.right().get());
        }
    }

    public static SetBigBookPageInLecternPacket decode(FriendlyByteBuf buf) {
        int page = buf.readInt();
        boolean isHand = buf.readBoolean();
        Either<InteractionHand, BlockPos> target = isHand
                ? Either.left(buf.readBoolean() ? InteractionHand.MAIN_HAND : InteractionHand.OFF_HAND)
                : Either.right(buf.readBlockPos());
        return new SetBigBookPageInLecternPacket(page, target);
    }

    public static void handle(SetBigBookPageInLecternPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            if (ctx.get().getSender() == null) return;
            Player player = ctx.get().getSender();
            msg.target().ifLeft(left -> updateStack(player.getItemInHand(left), msg.page()));
            msg.target().ifRight(right -> LecternUtil.tryGetLecternAndRun(player.level(), right, lectern -> {
                updateStack(lectern.getBook(), msg.page());
                setLecternPage(lectern, msg.page());
            }));
        });
        ctx.get().setPacketHandled(true);
    }

    /** 1.20.1: LecternBlockEntity.setPage(int) is not public; use reflection. */
    private static void setLecternPage(net.minecraft.world.level.block.entity.LecternBlockEntity lectern, int page) {
        try {
            java.lang.reflect.Method m = lectern.getClass().getDeclaredMethod("setPage", int.class);
            m.setAccessible(true);
            m.invoke(lectern, page);
        } catch (Exception ignored) {}
    }

    private static void updateStack(ItemStack stack, int page) {
        if (stack.getOrCreateTag().contains(BigBookContent.NBT_KEY)) {
            BigBookContent bc = BigBookContent.getFromStack(stack);
            if (!bc.pages().isEmpty()) {
                int clamped = Math.min(Math.max(page, 0), bc.pages().size() - 1);
                BigBookContent.setOnStack(stack, new BigBookContent(new ArrayList<>(bc.pages()), clamped));
            }
        }
        if (stack.getOrCreateTag().contains(WrittenBigBookContent.NBT_KEY)) {
            WrittenBigBookContent wbc = WrittenBigBookContent.getFromStack(stack);
            if (!wbc.pages().isEmpty()) {
                int clamped = Math.min(Math.max(page, 0), wbc.pages().size() - 1);
                WrittenBigBookContent.setOnStack(stack, new WrittenBigBookContent(new ArrayList<>(wbc.pages()), wbc.title(), wbc.author(), wbc.generation(), clamped));
            }
        }
    }
}
