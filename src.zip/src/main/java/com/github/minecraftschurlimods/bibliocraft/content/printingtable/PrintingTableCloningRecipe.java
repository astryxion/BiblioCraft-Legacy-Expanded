package com.github.minecraftschurlimods.bibliocraft.content.printingtable;

import com.github.minecraftschurlimods.bibliocraft.init.BCRecipes;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;

import java.util.ArrayList;
import java.util.List;

public class PrintingTableCloningRecipe extends PrintingTableRecipe {
    public static final MapCodec<PrintingTableCloningRecipe> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
            DataComponentType.CODEC.listOf(1, 256).fieldOf("data_components").forGetter(e -> e.dataComponentTypes),
            Ingredient.CODEC_NONEMPTY.listOf().fieldOf("ingredients").forGetter(e -> e.ingredients),
            ItemStack.CODEC.fieldOf("result").forGetter(e -> e.result),
            Codec.INT.fieldOf("duration").forGetter(e -> e.duration)
    ).apply(inst, PrintingTableCloningRecipe::new));
    public static final StreamCodec<RegistryFriendlyByteBuf, PrintingTableCloningRecipe> STREAM_CODEC = StreamCodec.composite(
            DataComponentType.STREAM_CODEC.apply(ByteBufCodecs.list()), e -> e.dataComponentTypes,
            Ingredient.CONTENTS_STREAM_CODEC.apply(ByteBufCodecs.list()), e -> e.ingredients,
            ItemStack.STREAM_CODEC, e -> e.result,
            ByteBufCodecs.INT, e -> e.duration,
            PrintingTableCloningRecipe::new);
    protected final List<DataComponentType<?>> dataComponentTypes;
    protected final List<Ingredient> ingredients;

    public PrintingTableCloningRecipe(List<DataComponentType<?>> dataComponentTypes, List<Ingredient> ingredients, ItemStack result, int duration) {
        super(result, duration);
        this.dataComponentTypes = dataComponentTypes;
        this.ingredients = ingredients;
    }

    @Override
    public boolean matches(PrintingTableRecipeInput input, Level level) {
        if (input.left().isEmpty()) return false;
        if (input.right().isEmpty()) return false;
        if (!input.right().is(result.getItem())) return false;
        if (!dataComponentTypes.stream().allMatch(e -> input.right().has(e))) return false;
        if (input.left().stream().filter(e -> e != ItemStack.EMPTY).count() != ingredients.size()) return false;
        List<Ingredient> copy = new ArrayList<>(ingredients);
        outer:
        for (int i = 0; i < input.left().size(); i++) {
            ItemStack stack = input.getItem(i);
            if (stack.isEmpty()) continue;
            for (Ingredient ingredient : copy) {
                if (ingredient.test(stack)) {
                    copy.remove(ingredient);
                    continue outer;
                }
            }
            return false;
        }
        return copy.isEmpty();
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    @Override
    public ItemStack assemble(PrintingTableRecipeInput input, HolderLookup.Provider registries) {
        ItemStack stack = result.copy();
        for (DataComponentType type : dataComponentTypes) {
            stack.set(type, input.right().get(type));
        }
        return stack;
    }

    @Override
    public RecipeSerializer<?> getSerializer() {
        return BCRecipes.PRINTING_TABLE_CLONING.get();
    }

    @Override
    public PrintingTableMode getMode() {
        return PrintingTableMode.CLONE;
    }

    @Override
    public NonNullList<ItemStack> getRemainingItems(PrintingTableRecipeInput input) {
        NonNullList<ItemStack> remainingItems = super.getRemainingItems(input);
        remainingItems.set(9, input.right().copy());
        return remainingItems;
    }

    @Override
    public Pair<List<Ingredient>, Ingredient> getDisplayIngredients() {
        return Pair.of(ingredients, Ingredient.of(result));
    }

    public static class Builder extends PrintingTableRecipe.Builder {
        private final List<DataComponentType<?>> dataComponentTypes = new ArrayList<>();
        private final List<Ingredient> ingredients = new ArrayList<>();

        public Builder(ItemStack result, int duration) {
            super(result, duration);
        }

        public Builder addDataComponentType(DataComponentType<?> type) {
            dataComponentTypes.add(type);
            return this;
        }

        public Builder addIngredient(Ingredient ingredient) {
            ingredients.add(ingredient);
            return this;
        }

        @Override
        public PrintingTableRecipe build() {
            return new PrintingTableCloningRecipe(dataComponentTypes, List.copyOf(ingredients), result, duration);
        }
    }
}
